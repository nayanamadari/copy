/**
 * 
 */
/**
 * @author MSIS
 *
 */
module StudentApplication {
	requires java.sql;
}