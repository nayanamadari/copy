package com.student.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;


public class StudentDAO implements Implementations{
	int bal;
	@Override
	public void viewStudentDetails(Connection connection) throws SQLException {
		
		String rollno=null;
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		try
		{	
			String query1 = "SELECT * FROM Academic Details";
			Statement stmt = connection.createStatement();
			//System.out.println("Enter the Roll number :");
			//String rollno = sc.next();
			//stmt.setString(0, rollno);
			stmt.executeQuery(query1);
			/*ResultSet rs =stmt.executeQuery();
			while(rs.next())
			{
				System.out.println("Roll No    Name     Branch      Balance\n");
				System.out.println(rs.getString(0)+ "     "+ rs.getString(1)+ "      "+ rs.getString(2)+ "     "+ rs.getInt(3));
			}*/
		}
		catch(Exception e)
		{
			System.err.print("An Error Occured\n");
			if(connection!=null)
				connection.close();
			e.printStackTrace();
		}
	}

	

	public void payBalance(Connection connection1, Connection connection2) throws SQLException {
		// TODO Auto-generated method stub
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		ResultSet rs = null;
		
		
		
		try
		{	
			//Set AutoCommit as FALSE
			connection1.setAutoCommit(false);
			connection2.setAutoCommit(false);
			
			
			//Updation in Finance_Details
			System.out.println("Enter the Roll number :");
			String rollno = sc.next();
			System.out.println("Enter the Balance Amount :");
			int balance = sc.nextInt();
			String query1 = "UPDATE Finance_Details2 SET Balance= (Balance - ? ) WHERE Roll_No= ?";
			PreparedStatement stmt = connection2.prepareStatement(query1);
			stmt.setInt(1, balance);
			stmt.setString(2, rollno);
			//stmt.executeQuery(query1);
			int i=stmt.executeUpdate();  
			System.out.println(i+" records updated"); 
				try {
				String query2 = "SELECT * FROM Finance_Details2 WHERE Roll_No=?";
				PreparedStatement stmt2= connection2.prepareStatement(query2);
				
				stmt2.setString(1, rollno);
				rs=stmt2.executeQuery();
				bal= rs.getInt(4);
				while(rs.next())
				{  
					System.out.println(rs.getString(1)+ " " + rs.getString(2)+"  "+ rs.getString(3)+"  "+rs.getInt(4));
					
					System.out.println(bal);
				}
				}catch(Exception e) { e.printStackTrace();}
			
			//Updation in Academic_Details
				try {
			if(bal==0)
			{
				String query3 = "UPDATE Academic_Details SET Due=0 WHERE Roll_No= ?";
				PreparedStatement stmt3 = connection1.prepareStatement(query3);
				//System.out.println("Enter the Roll number :");
				//String rollno1 = sc.next();
				stmt3.setString(1, rollno);
				//stmt3.executeQuery(query3);
				int j=stmt3.executeUpdate();  
				System.out.println(j+" records updated"); 
			}
				}
				catch(Exception e) { e.printStackTrace();}
			
			//if both transactions are sucessfull then commit the transactions
			connection2.commit();
			connection1.commit();
			
		}
		catch(Exception e)
		{
			System.err.print("An Error Occured\n");
			if(connection2!=null) {
				System.out.println("Rollbacking all the transactions.......");
				connection2.rollback();
				connection2.close();
			}
			if(connection2!=null) {
				System.out.println("Rollbacking all the transactions.......");
				connection2.rollback();
				connection2.close();
			}
			e.printStackTrace();
		}
		
	}
	

}

