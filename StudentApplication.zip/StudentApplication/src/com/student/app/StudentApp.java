package com.student.app;
import com.student.database.*;
import com.student.impl.*;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;

public class StudentApp {

	public static void main(String[] args) throws IOException, SQLException {
		Scanner sc = new Scanner(System.in);
		
		//Database Connection
		DatabaseConnnection db = new DatabaseConnnection();
		Connection connection1=db.databaseConnect1();
		Connection connection2=db.databaseConnect2();
		
		//Student Application Business Logic
		StudentDAO dao = new StudentDAO();
		
		
		System.out.println("Welocome to Student Application\n");
		System.out.println("Enter your choice\n");
		System.out.println("\t1.View Student Details\n \t2.Pay the balance amount\n \t3.Exit the Application\n");
		int choice= sc.nextInt();
		while(choice>0)
		{
			switch(choice)
			{
				case 1: dao.viewStudentDetails(connection1);
						break;
				case 2: dao.payBalance(connection1,connection2);
						break;
				case 3:{System.out.println("Thank You");
						System.exit(0);
						break;
						}
				default: System.out.println("Please enter the valid choice");
			}		
		}
	}

}
