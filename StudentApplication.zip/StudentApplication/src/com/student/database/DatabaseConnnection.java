
package com.student.database;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class DatabaseConnnection {
	
	//Connection to Database "221047011"
	public Connection databaseConnect1() throws IOException
	{
		Connection connection = null;
		Properties properties = new Properties();
		FileReader fread = new FileReader("F:\\Eclipse\\StudentApplication\\src\\db.properties");
		properties.load(fread);
		try
		{
			String connectionURL = "jdbc:sqlserver://172.16.51.38;" + "databaseName="+ properties.getProperty("dbName1")
			+ ";" + "integratedSecurity=false;" + "user=" + properties.getProperty("user") +";"
			+ "password=" + properties.getProperty("password") + ";" ;
			
			connection = DriverManager.getConnection(connectionURL);
			
			if(connection!=null)
			{
				System.out.println("Sucessfully connected to Database 1");
			}
		}
		catch(Exception e)
		{
			System.err.print("Couldn't connect to Database 1");
			e.printStackTrace();
		}
		return connection;	
	}
	
	//Connection to Database "ExamDB"
	public Connection databaseConnect2() throws IOException
	{
		Connection connection = null;
		Properties properties = new Properties();
		FileReader fread = new FileReader("F:\\Eclipse\\StudentApplication\\src\\db.properties");
		properties.load(fread);
		try
		{
			String connectionURL = "jdbc:sqlserver://172.16.51.38;" + "databaseName="+ properties.getProperty("dbName2")
			+ ";" + "integratedSecurity=false;" + "user=" + properties.getProperty("user") +";"
			+ "password=" + properties.getProperty("password") + ";" ;
				
			connection = DriverManager.getConnection(connectionURL);
				
			if(connection!=null)
			{
				System.out.println("Sucessfully connected to Database 1");
			}
		}
		catch(Exception e)
		{
			System.err.print("Couldn't connect to Database 1");
			e.printStackTrace();
		}
		return connection;	
		}	
	

}
