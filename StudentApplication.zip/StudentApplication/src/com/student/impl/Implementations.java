
package com.student.impl;

import java.sql.Connection;
import java.sql.SQLException;

public interface Implementations {
	public void viewStudentDetails(Connection connection) throws SQLException;
	public void payBalance(Connection connection1, Connection connection2) throws SQLException;

}
